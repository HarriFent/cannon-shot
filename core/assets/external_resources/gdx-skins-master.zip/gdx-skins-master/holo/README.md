# Holo skin

Inspired by Android UI. Features styles of most of the **Scene2D** actors. Comes in two themes (light and dark) and four sizes, giving you ***eight*** skins to choose from. Raw assets (PNGs) are included.

![Holo](preview.png)

### License

None in particular, but make sure to credit [Carsten](http://www.badlogicgames.com/forum/viewtopic.php?f=22&t=8533).
