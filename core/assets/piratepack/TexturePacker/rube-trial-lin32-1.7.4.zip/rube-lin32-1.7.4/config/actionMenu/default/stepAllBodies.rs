//Name: Step all bodies
//Tags: physics, step, simulation
//Runs the physics simulation for all bodies.

step( ab(), queryNumericValue("Number of steps:", 60) );
