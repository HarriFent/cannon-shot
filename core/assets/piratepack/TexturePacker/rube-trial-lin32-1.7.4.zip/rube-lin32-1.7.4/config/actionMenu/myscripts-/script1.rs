print("This is script 1");
