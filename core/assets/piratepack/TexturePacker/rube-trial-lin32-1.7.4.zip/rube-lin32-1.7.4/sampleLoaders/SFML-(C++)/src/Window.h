#ifndef WINDOW_H
#define WINDOW_H

sf::RenderWindow* getWindow();

#endif // WINDOW_H
