//
//  MenuScreenRUBELayer.h
//  check8_v2
//
//  Created by chris on 16/09/13.
//  Copyright (c) 2013 chris. All rights reserved.
//

#import "ButtonRUBELayer.h"

@interface MenuScreenRUBELayer : ButtonRUBELayer

@end
